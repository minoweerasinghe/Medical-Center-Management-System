"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AlertCircle, CheckCircle2, Clock } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

type Step = "verify" | "check-owner" | "delete-or-transfer" | "transfer-details"

interface FamilyMember {
  id: string
  name: string
  nic: string
  contact: string
  role: "owner" | "member"
}

export default function ProfileTransferPage() {
  const [step, setStep] = useState<Step>("verify")
  const [isOwner, setIsOwner] = useState(false)
  const [selectedFamilyMember, setSelectedFamilyMember] = useState<FamilyMember | null>(null)
  const [transferAction, setTransferAction] = useState<"delete" | "transfer" | null>(null)
  const [targetUsername, setTargetUsername] = useState("")
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  
  const [verifyData, setVerifyData] = useState({
    username: "",
    password: "",
    otp: "",
  })

  // Mock family members with NIC and contact
  const familyMembers: FamilyMember[] = [
    {
      id: "001",
      name: "Pramudi Perera",
      nic: "123456789V",
      contact: "074 0235792",
      role: "owner",
    },
    {
      id: "003",
      name: "Rohith Perera",
      nic: "987654321V",
      contact: "075 1234567",
      role: "member",
    },
    {
      id: "004",
      name: "Aisha Perera",
      nic: "456789123V",
      contact: "076 2345678",
      role: "member",
    },
  ]

  const handleVerifyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setVerifyData((prev) => ({ ...prev, [name]: value }))
  }

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault()
    if (verifyData.username && verifyData.password && verifyData.otp) {
      // Mock check - user is owner
      setIsOwner(true)
      setStep("check-owner")
    }
  }

  const handleSelectNewOwner = (member: FamilyMember) => {
    setSelectedFamilyMember(member)
    setStep("delete-or-transfer")
  }

  const handleTransferAction = (action: "delete" | "transfer") => {
    setTransferAction(action)
    if (action === "transfer") {
      setStep("transfer-details")
    } else {
      setShowConfirmDialog(true)
    }
  }

  const handleSendTransferRequest = (e: React.FormEvent) => {
    e.preventDefault()
    if (targetUsername && selectedFamilyMember) {
      setShowConfirmDialog(true)
    }
  }

  const handleBack = () => {
    if (step === "delete-or-transfer") {
      setStep("check-owner")
      setTransferAction(null)
      setSelectedFamilyMember(null)
    } else if (step === "transfer-details") {
      setStep("delete-or-transfer")
      setTargetUsername("")
    } else if (step === "check-owner") {
      setStep("verify")
      setIsOwner(false)
    } else {
      setStep("verify")
      setVerifyData({ username: "", password: "", otp: "" })
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Profile Transfer</h1>
        <p className="text-gray-600">Transfer your account to another family member or delete your profile</p>
      </div>

      <Card className="p-8 bg-white max-w-3xl">
        {/* Step 1: Verify Account */}
        {step === "verify" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Verify Your Account</h2>
            <p className="text-gray-600 mb-6">For security, we need to verify your account before proceeding</p>

            <form onSubmit={handleVerify} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Username</label>
                <Input
                  type="text"
                  name="username"
                  placeholder="Enter your username"
                  value={verifyData.username}
                  onChange={handleVerifyChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Password</label>
                <Input
                  type="password"
                  name="password"
                  placeholder="Enter your password"
                  value={verifyData.password}
                  onChange={handleVerifyChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">OTP</label>
                <div className="flex gap-3">
                  <Input
                    type="text"
                    name="otp"
                    placeholder="Enter OTP"
                    value={verifyData.otp}
                    onChange={handleVerifyChange}
                    required
                  />
                  <Button type="button" variant="outline" className="px-6">
                    Request OTP
                  </Button>
                </div>
              </div>

              <Button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 font-semibold"
              >
                Verify Account
              </Button>
            </form>
          </div>
        )}

        {/* Step 2: Check if Owner */}
        {step === "check-owner" && (
          <div className="space-y-6">
            {isOwner ? (
              <>
                <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                  <div>
                    <p className="font-semibold text-green-900">Account Verified</p>
                    <p className="text-sm text-green-700">You are the account owner</p>
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Select New Account Owner</h2>
                  <p className="text-gray-600 mb-6">Choose a family member with verified NIC number and contact to transfer ownership</p>

                  <div className="space-y-3">
                    {familyMembers.filter(m => m.id !== "001").map((member) => (
                      <button
                        key={member.id}
                        onClick={() => handleSelectNewOwner(member)}
                        className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-semibold text-gray-900">{member.name}</p>
                            <p className="text-sm text-gray-600">NIC: {member.nic}</p>
                            <p className="text-sm text-gray-600">Contact: {member.contact}</p>
                          </div>
                          <div className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium">
                            {member.role}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-6 border-t">
                  <Button 
                    onClick={handleBack}
                    className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-900 font-semibold py-3"
                  >
                    Back
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex items-start gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <AlertCircle className="h-6 w-6 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-yellow-900">Not Account Owner</p>
                  <p className="text-sm text-yellow-700">Only the account owner can initiate profile transfers</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 3: Delete or Transfer */}
        {step === "delete-or-transfer" && selectedFamilyMember && (
          <div className="space-y-6">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-gray-700">
                <span className="font-semibold">New Account Owner:</span> {selectedFamilyMember.name}
              </p>
            </div>

            <h2 className="text-2xl font-bold text-gray-900">What would you like to do?</h2>

            <div className="space-y-3">
              <button
                onClick={() => handleTransferAction("transfer")}
                className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all text-left"
              >
                <div className="flex items-start gap-3">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">Transfer to Another Account</p>
                    <p className="text-sm text-gray-600">Send transfer request to another account owner for approval</p>
                  </div>
                </div>
              </button>

              <button
                onClick={() => handleTransferAction("delete")}
                className="w-full p-4 border-2 border-red-200 rounded-lg hover:border-red-500 hover:bg-red-50 transition-all text-left"
              >
                <div className="flex items-start gap-3">
                  <div className="flex-1">
                    <p className="font-semibold text-red-900">Delete Account</p>
                    <p className="text-sm text-red-700">Permanently delete this profile and transfer data</p>
                  </div>
                </div>
              </button>
            </div>

            <div className="flex gap-3 pt-6 border-t">
              <Button 
                onClick={handleBack}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-900 font-semibold py-3"
              >
                Back
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Transfer to Another Account */}
        {step === "transfer-details" && selectedFamilyMember && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Transfer to Another Account</h2>
              <p className="text-gray-600">Enter the username of the target account owner</p>
            </div>

            <form onSubmit={handleSendTransferRequest} className="space-y-6">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm">
                  <span className="font-semibold">From Account Owner:</span> {selectedFamilyMember.name}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Target Account Owner Username</label>
                <Input
                  type="text"
                  placeholder="Enter the username of account owner to receive this profile"
                  value={targetUsername}
                  onChange={(e) => setTargetUsername(e.target.value)}
                  required
                />
                <p className="text-xs text-gray-500 mt-2">We will send a transfer request to this account owner</p>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-gray-700">
                  <span className="font-semibold">Note:</span> The account owner will receive a request to accept this profile transfer. They can approve or reject it.
                </p>
              </div>

              <div className="flex gap-3 pt-6 border-t">
                <Button 
                  type="button"
                  onClick={handleBack}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-900 font-semibold py-3"
                >
                  Back
                </Button>
                <Button 
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
                >
                  Send Transfer Request
                </Button>
              </div>
            </form>
          </div>
        )}
      </Card>

      {/* Confirmation Dialog for Delete */}
      <Dialog open={showConfirmDialog && transferAction === "delete"} onOpenChange={(open) => {
        if (!open) {
          setShowConfirmDialog(false)
          setTransferAction(null)
        }
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-red-600">Confirm Account Deletion</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">
                <span className="font-semibold">Warning:</span> This action is permanent and cannot be undone. Your profile and all associated data will be deleted.
              </p>
            </div>
            <p className="text-gray-700">
              Are you sure you want to delete your profile and transfer data to <span className="font-semibold">{selectedFamilyMember?.name}</span>?
            </p>
            <div className="flex gap-3 pt-4">
              <Button 
                onClick={() => {
                  setShowConfirmDialog(false)
                  setTransferAction(null)
                }}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-900 font-semibold"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  setShowConfirmDialog(false)
                  setTransferAction(null)
                  // Handle deletion
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold"
              >
                Confirm Deletion
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Transfer Request Sent Dialog */}
      <Dialog open={showConfirmDialog && transferAction === "transfer"} onOpenChange={(open) => {
        if (!open) {
          setShowConfirmDialog(false)
          setTransferAction(null)
        }
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Transfer Request Sent</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <div className="text-center">
              <p className="font-semibold text-gray-900">Request Sent Successfully!</p>
              <p className="text-sm text-gray-600 mt-2">
                Transfer request has been sent to <span className="font-semibold">{targetUsername}</span>
              </p>
            </div>
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-gray-700">
                <span className="font-semibold">Status:</span> Pending approval from account owner
              </p>
              <div className="flex items-center gap-2 mt-2 text-blue-700">
                <Clock className="h-4 w-4" />
                <span className="text-sm">Waiting for response...</span>
              </div>
            </div>
            <Button 
              onClick={() => {
                setShowConfirmDialog(false)
                setTransferAction(null)
              }}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold"
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
