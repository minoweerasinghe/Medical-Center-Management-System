"use client"

import type React from "react"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

export function LoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log({ username, password, role })
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md space-y-4">
      <div className="space-y-2">
        <Label htmlFor="username" className="text-foreground font-medium">
          Username
        </Label>
        <Input
          id="username"
          type="text"
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="border-[#0891b2] focus:ring-[#0891b2]"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password" className="text-foreground font-medium">
          Password
        </Label>
        <Input
          id="password"
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border-[#0891b2] focus:ring-[#0891b2]"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="role" className="text-foreground font-medium">
          Role
        </Label>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="border-[#0891b2]">
            <SelectValue placeholder="Select Role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="doctor">Doctor</SelectItem>
            <SelectItem value="patient">Patient</SelectItem>
            <SelectItem value="medical center assistant">Medical center assistant</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1 text-sm">
        <Link href="/reset-password" className="text-[#0891b2] hover:underline block">
          Reset Password?
        </Link>
        <p className="text-[#0891b2]">
          If you don't have an account,{" "}
          <Link href="/signup" className="hover:underline">
            Create one
          </Link>
        </p>
      </div>

      <div className="space-y-3 pt-2">
        <Button type="submit" className="w-full bg-[#38bdf8] hover:bg-[#0ea5e9] text-white font-medium py-2">
          Login
        </Button>
      </div>
    </form>
  )
}
